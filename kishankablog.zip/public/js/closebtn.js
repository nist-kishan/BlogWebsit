let closebtn=document.querySelector('#closebtn')

closebtn.addEventListener('click',()=>{
    history.go(-1)
})